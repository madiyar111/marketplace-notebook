import { Router } from "express";
import { requireAuth, requireRole } from "../middleware/auth.js";
import {
  createOrder,
  myOrders,
  cancelOrder,
  deleteOrder,
  updateOrderItemQty,
  removeOrderItem
} from "../controllers/order.controller.js";

const r = Router();

r.post("/", requireAuth, createOrder);
r.get("/my", requireAuth, myOrders);

r.patch("/:id/cancel", requireAuth, cancelOrder);
r.patch("/:id/item", requireAuth, updateOrderItemQty);
r.delete("/:id/item/:productId", requireAuth, removeOrderItem);

r.delete("/:id", requireAuth, requireRole("admin"), deleteOrder);

export default r;
