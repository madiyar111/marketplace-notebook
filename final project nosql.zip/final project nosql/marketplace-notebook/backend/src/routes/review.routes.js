import { Router } from "express";
import { requireAuth } from "../middleware/auth.js";
import { createReview, listProductReviews } from "../controllers/review.controller.js";

const r = Router();

r.post("/", requireAuth, createReview);
r.get("/product/:productId", listProductReviews);

export default r;
