import { Router } from "express";
import { requireAuth, requireRole } from "../middleware/auth.js";
import {
  topProducts,
  revenueSummary,
  overview,
  ordersByStatus,
  productsByCategory,
} from "../controllers/analytics.controller.js";

const r = Router();

r.get("/overview", requireAuth, requireRole("admin"), overview);
r.get("/orders-by-status", requireAuth, requireRole("admin"), ordersByStatus);
r.get("/products-by-category", requireAuth, requireRole("admin"), productsByCategory);

r.get("/top-products", requireAuth, requireRole("admin"), topProducts);
r.get("/revenue", requireAuth, requireRole("admin"), revenueSummary);

export default r;
