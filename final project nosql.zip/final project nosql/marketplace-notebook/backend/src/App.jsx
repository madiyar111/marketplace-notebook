import React from "react";
import { Link, Routes, Route, useNavigate } from "react-router-dom";
import { clearAuth, getUser } from "./auth";

import Login from "./pages/Login.jsx";
import Register from "./pages/Register.jsx";
import Products from "./pages/Products.jsx";
import AdminAnalytics from "./pages/AdminAnalytics.jsx";

function Nav() {
  const user = getUser();
  const nav = useNavigate();

  return (
    <div className="nav">
      <div className="navInner">
        <div className="brand">
          Marketplace Notebook <span className="badge">NoSQL</span>
        </div>

        <div className="navLinks">
          <Link to="/products">Products</Link>
          <Link to="/analytics">Analytics</Link>
        </div>

        <div className="right">
          {user ? (
            <>
              <div className="pill">{user.name} · {user.role}</div>
              <button className="btn secondary" onClick={() => { clearAuth(); nav("/login"); }}>
                Logout
              </button>
            </>
          ) : (
            <>
              <Link className="btn secondary" to="/login">Login</Link>
              <Link className="btn" to="/register">Register</Link>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <div>
      <Nav />
      <div className="container">
        <Routes>
          <Route path="/" element={<Products />} />
          <Route path="/products" element={<Products />} />
          <Route path="/analytics" element={<AdminAnalytics />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="*" element={<div className="card">Not found</div>} />
        </Routes>
      </div>
    </div>
  );
}
