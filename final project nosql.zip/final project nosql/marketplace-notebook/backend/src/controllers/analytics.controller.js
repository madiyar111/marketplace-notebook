import asyncHandler from "../utils/asyncHandler.js";
import Order from "../models/Order.js";
import Product from "../models/Product.js";
import User from "../models/User.js";

// existing: top products by paid orders
export const topProducts = asyncHandler(async (req, res) => {
  const pipeline = [
    { $match: { status: "paid" } },
    { $unwind: "$items" },
    {
      $group: {
        _id: "$items.productId",
        totalSold: { $sum: "$items.quantity" },
        revenue: { $sum: { $multiply: ["$items.quantity", "$items.priceAtPurchase"] } },
      },
    },
    { $sort: { totalSold: -1 } },
    { $limit: 10 },
    {
      $lookup: {
        from: "products",
        localField: "_id",
        foreignField: "_id",
        as: "product",
      },
    },
    { $unwind: "$product" },
    {
      $project: {
        _id: 0,
        productId: "$product._id",
        title: "$product.title",
        category: "$product.category",
        totalSold: 1,
        revenue: 1,
      },
    },
  ];

  const result = await Order.aggregate(pipeline);
  res.json(result);
});

// existing: revenue summary
export const revenueSummary = asyncHandler(async (req, res) => {
  const pipeline = [
    { $match: { status: "paid" } },
    {
      $group: {
        _id: null,
        revenue: { $sum: "$totalPrice" },
        totalOrders: { $sum: 1 },
        avgOrderValue: { $avg: "$totalPrice" },
      },
    },
    { $project: { _id: 0, revenue: 1, totalOrders: 1, avgOrderValue: 1 } },
  ];

  const [result] = await Order.aggregate(pipeline);
  res.json(result || { revenue: 0, totalOrders: 0, avgOrderValue: 0 });
});

// ✅ NEW: overview counts (works even with no orders)
export const overview = asyncHandler(async (req, res) => {
  const [users, products, orders] = await Promise.all([
    User.countDocuments(),
    Product.countDocuments(),
    Order.countDocuments(),
  ]);

  const byStatusAgg = await Order.aggregate([
    { $group: { _id: "$status", count: { $sum: 1 }, revenue: { $sum: "$totalPrice" } } },
  ]);

  const statuses = { pending: 0, paid: 0, cancelled: 0 };
  for (const x of byStatusAgg) {
    statuses[x._id] = x.count;
  }

  res.json({ users, products, orders, statuses });
});

// ✅ NEW: orders by status
export const ordersByStatus = asyncHandler(async (req, res) => {
  const agg = await Order.aggregate([
    {
      $group: {
        _id: "$status",
        count: { $sum: 1 },
        revenue: { $sum: "$totalPrice" },
      },
    },
    { $project: { _id: 0, status: "$_id", count: 1, revenue: 1 } },
    { $sort: { count: -1 } },
  ]);

  res.json(agg);
});

// ✅ NEW: products grouped by category (works even with no orders)
export const productsByCategory = asyncHandler(async (req, res) => {
  const agg = await Product.aggregate([
    {
      $group: {
        _id: "$category",
        count: { $sum: 1 },
        avgPrice: { $avg: "$price" },
        minPrice: { $min: "$price" },
        maxPrice: { $max: "$price" },
        avgStock: { $avg: "$stock" },
      },
    },
    { $sort: { count: -1 } },
    { $limit: 15 },
    {
      $project: {
        _id: 0,
        category: "$_id",
        count: 1,
        avgPrice: 1,
        minPrice: 1,
        maxPrice: 1,
        avgStock: 1,
      },
    },
  ]);

  res.json(agg);
});
