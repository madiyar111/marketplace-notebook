import asyncHandler from "../utils/asyncHandler.js";
import Review from "../models/Review.js";

export const createReview = asyncHandler(async (req, res) => {
  const { productId, rating, comment } = req.body;
  if (!productId || !rating) return res.status(400).json({ message: "productId and rating required" });

  const review = await Review.create({
    productId,
    userId: req.user._id,
    rating,
    comment: comment || ""
  });

  res.status(201).json(review);
});

export const listProductReviews = asyncHandler(async (req, res) => {
  const reviews = await Review.find({ productId: req.params.productId }).sort({ createdAt: -1 });
  res.json(reviews);
});

