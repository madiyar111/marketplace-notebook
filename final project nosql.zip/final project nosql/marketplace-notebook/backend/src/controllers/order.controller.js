import asyncHandler from "../utils/asyncHandler.js";
import Order from "../models/Order.js";
import Product from "../models/Product.js";

// Convert price safely even if stored like "₹62 990" or "62,990"
function toNumberPrice(val) {
  if (typeof val === "number") return val;
  const cleaned = String(val ?? "").replace(/[^0-9.]/g, ""); // remove currency, commas, spaces
  if (!cleaned) return NaN;
  return Number(cleaned);
}

function computeTotal(items) {
  return items.reduce((sum, it) => sum + it.quantity * it.priceAtPurchase, 0);
}

async function rollbackStock(decremented) {
  await Promise.allSettled(
    decremented.map((d) =>
      Product.updateOne({ _id: d.productId }, { $inc: { stock: d.quantity } })
    )
  );
}

// POST /orders  (checkout)
export const createOrder = asyncHandler(async (req, res) => {
  const { items } = req.body;

  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ message: "Items required" });
  }

  const embedded = [];
  const decremented = [];

  try {
    for (const it of items) {
      const productId = it.productId;
      const qty = Number(it.quantity);

      if (!productId) throw new Error("productId required");
      if (!Number.isFinite(qty) || qty < 1) throw new Error("Invalid quantity");

      // Atomic decrement ONLY if enough stock exists
      const p = await Product.findOneAndUpdate(
        { _id: productId, stock: { $gte: qty } },
        { $inc: { stock: -qty } },
        { new: true }
      );

      if (!p) {
        const exists = await Product.findById(productId)
          .select("title stock")
          .lean();
        if (!exists) throw new Error("Product not found: " + productId);
        throw new Error(`Not enough stock for ${exists.title}`);
      }

      const price = toNumberPrice(p.price);
      if (!Number.isFinite(price)) {
        throw new Error(`Invalid product price for ${p.title ?? p._id}`);
      }

      embedded.push({
        productId: p._id,
        quantity: qty,
        priceAtPurchase: price, // ✅ required by schema
      });

      decremented.push({ productId: p._id, quantity: qty });
    }

    const totalPrice = computeTotal(embedded);
    if (!Number.isFinite(totalPrice)) throw new Error("Total price calculation failed");

    const order = await Order.create({
      userId: req.user._id,
      items: embedded,
      totalPrice, // ✅ required by schema
      status: "paid",
    });

    res.status(201).json(order);
  } catch (e) {
    await rollbackStock(decremented);
    res.status(400).json({ message: e.message });
  }
});

// GET /orders/my
export const myOrders = asyncHandler(async (req, res) => {
  const orders = await Order.find({ userId: req.user._id }).sort({ createdAt: -1 });
  res.json(orders);
});

// PATCH /orders/:id/cancel
export const cancelOrder = asyncHandler(async (req, res) => {
  const order = await Order.findById(req.params.id);
  if (!order) return res.status(404).json({ message: "Order not found" });

  if (req.user.role !== "admin" && String(order.userId) !== String(req.user._id)) {
    return res.status(403).json({ message: "Forbidden" });
  }

  if (order.status === "cancelled") {
    return res.status(400).json({ message: "Already cancelled" });
  }

  // Guard against double-cancel
  const updated = await Order.findOneAndUpdate(
    { _id: order._id, status: { $ne: "cancelled" } },
    { $set: { status: "cancelled" } },
    { new: true }
  );

  if (!updated) return res.status(400).json({ message: "Already cancelled" });

  // Restock best-effort (no transaction)
  await Promise.allSettled(
    updated.items.map((it) =>
      Product.updateOne({ _id: it.productId }, { $inc: { stock: it.quantity } })
    )
  );

  res.json(updated);
});

export const deleteOrder = asyncHandler(async (req, res) => {
  const order = await Order.findById(req.params.id);
  if (!order) return res.status(404).json({ message: "Order not found" });
  await order.deleteOne();
  res.json({ message: "Deleted" });
});

export const updateOrderItemQty = asyncHandler(async (req, res) => {
  const { productId, quantity } = req.body;
  const qty = Number(quantity);

  if (!productId || !Number.isFinite(qty) || qty < 1) {
    return res.status(400).json({ message: "productId and valid quantity required" });
  }

  const order = await Order.findById(req.params.id);
  if (!order) return res.status(404).json({ message: "Order not found" });

  if (req.user.role !== "admin" && String(order.userId) !== String(req.user._id)) {
    return res.status(403).json({ message: "Forbidden" });
  }

  const updated = await Order.findOneAndUpdate(
    { _id: req.params.id, "items.productId": productId },
    { $set: { "items.$.quantity": qty } },
    { new: true }
  );

  if (!updated) return res.status(404).json({ message: "Item not found in order" });

  updated.totalPrice = computeTotal(updated.items);
  await updated.save();

  res.json(updated);
});

export const removeOrderItem = asyncHandler(async (req, res) => {
  const { id, productId } = req.params;

  const order = await Order.findById(id);
  if (!order) return res.status(404).json({ message: "Order not found" });

  if (req.user.role !== "admin" && String(order.userId) !== String(req.user._id)) {
    return res.status(403).json({ message: "Forbidden" });
  }

  const updated = await Order.findByIdAndUpdate(
    id,
    { $pull: { items: { productId } } },
    { new: true }
  );

  updated.totalPrice = computeTotal(updated.items);
  await updated.save();

  res.json(updated);
});
