import React from "react";
import { Navigate } from "react-router-dom";
import { getUser } from "../auth";

export default function ProtectedRoute({ roles, children }) {
  const user = getUser();
  if (!user) return <Navigate to="/login" replace />;

  if (roles && roles.length > 0 && !roles.includes(user.role)) {
    return <div className="card">Forbidden (role required)</div>;
  }
  return children;
}
