import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { api } from "../api";
import { getUser } from "../auth";
import {
  getCartItems,
  setQty,
  removeFromCart,
  clearCart,
  cartSubtotal,
} from "../cart";

export default function Cart() {
  const nav = useNavigate();
  const user = getUser();

  const [items, setItems] = React.useState(getCartItems());
  const [msg, setMsg] = React.useState("");
  const [loading, setLoading] = React.useState(false);

  // keep cart UI synced
  React.useEffect(() => {
    const refresh = () => setItems(getCartItems());
    window.addEventListener("cart:change", refresh);
    window.addEventListener("storage", refresh);
    return () => {
      window.removeEventListener("cart:change", refresh);
      window.removeEventListener("storage", refresh);
    };
  }, []);

  const subtotal = cartSubtotal();

  const checkout = async () => {
    setMsg("");

    if (!user) {
      setMsg("Please login to checkout.");
      nav("/login");
      return;
    }

    if (items.length === 0) {
      setMsg("Cart is empty.");
      return;
    }

    setLoading(true);
    try {
      // backend expects: { items: [{ productId, quantity }] }
      const payload = {
        items: items.map((it) => ({
          productId: it.productId,
          quantity: Number(it.qty || 1),
        })),
      };

      const res = await api.post("/orders", payload);

      clearCart();
      setMsg("✅ Order created successfully!");
      // optional: go to products after checkout
      // nav("/products");
      console.log("Order:", res.data);
    } catch (e) {
      console.error(e);
      setMsg(
        e?.response?.data?.message ||
          e?.message ||
          "Checkout failed (stock / auth / server)"
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="card">
      <div className="h1">Cart</div>
      <div className="sub">Review items and checkout</div>

      {msg && <div className="msgErr" style={{ marginBottom: 12 }}>{msg}</div>}

      {items.length === 0 ? (
        <div className="small">
          Your cart is empty. Go to <Link to="/products"><b>Products</b></Link>.
        </div>
      ) : (
        <>
          <div style={{ display: "grid", gap: 12 }}>
            {items.map((it) => (
              <div
                key={it.productId}
                style={{
                  display: "grid",
                  gridTemplateColumns: "90px 1fr 180px",
                  gap: 12,
                  alignItems: "center",
                  padding: 12,
                  borderRadius: 14,
                  border: "1px solid rgba(255,255,255,.08)",
                  background: "rgba(255,255,255,.03)",
                }}
              >
                <div
                  style={{
                    width: 90,
                    height: 64,
                    borderRadius: 12,
                    overflow: "hidden",
                    border: "1px solid rgba(255,255,255,.08)",
                    background: "rgba(255,255,255,.04)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontWeight: 900,
                  }}
                >
                  {it.imageUrl ? (
                    <img
                      src={it.imageUrl}
                      alt={it.title}
                      style={{ width: "100%", height: "100%", objectFit: "cover" }}
                      onError={(e) => (e.currentTarget.style.display = "none")}
                    />
                  ) : (
                    (it.title?.slice(0, 1) || "P").toUpperCase()
                  )}
                </div>

                <div>
                  <div style={{ fontWeight: 900 }}>{it.title}</div>
                  <div className="small">Price: ₹{Number(it.price || 0).toLocaleString()}</div>
                  <div className="small">
                    Line: ₹{(Number(it.price || 0) * Number(it.qty || 0)).toLocaleString()}
                  </div>
                </div>

                <div style={{ display: "grid", gap: 8 }}>
                  <div style={{ display: "flex", gap: 8 }}>
                    <button
                      className="btn"
                      onClick={() => setQty(it.productId, Number(it.qty || 1) - 1)}
                    >
                      −
                    </button>

                    <input
                      className="input"
                      value={it.qty}
                      onChange={(e) => setQty(it.productId, e.target.value)}
                      style={{ textAlign: "center" }}
                    />

                    <button
                      className="btn"
                      onClick={() => setQty(it.productId, Number(it.qty || 1) + 1)}
                    >
                      +
                    </button>
                  </div>

                  <button className="btn" onClick={() => removeFromCart(it.productId)}>
                    Remove
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginTop: 16,
              gap: 12,
              flexWrap: "wrap",
            }}
          >
            <div style={{ fontSize: 18, fontWeight: 900 }}>
              Subtotal: ₹{subtotal.toLocaleString()}
            </div>

            <div style={{ display: "flex", gap: 10 }}>
              <button className="btn" onClick={clearCart} disabled={loading}>
                Clear cart
              </button>
              <button className="btn primary" onClick={checkout} disabled={loading}>
                {loading ? "Processing..." : "Checkout"}
              </button>
            </div>
          </div>

          <div className="small" style={{ marginTop: 10 }}>
            Checkout creates an order in the backend and decreases stock.
          </div>
        </>
      )}
    </div>
  );
}
