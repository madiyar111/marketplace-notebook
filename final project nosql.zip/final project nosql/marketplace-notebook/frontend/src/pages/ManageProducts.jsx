import React from "react";
import { api } from "../api";
import { getUser } from "../auth";

export default function ManageProducts() {
  const user = getUser();
  const canManage = user && (user.role === "seller" || user.role === "admin");

  const [items, setItems] = React.useState([]);
  const [err, setErr] = React.useState("");
  const [msg, setMsg] = React.useState("");

  // form fields (create)
  const [title, setTitle] = React.useState("");
  const [category, setCategory] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [price, setPrice] = React.useState("");
  const [stock, setStock] = React.useState("");
  const [tags, setTags] = React.useState(""); // comma separated

  const load = React.useCallback(async () => {
    setErr("");
    try {
      const res = await api.get("/products");
      const data = res.data;
      setItems(Array.isArray(data) ? data : (data?.items ?? []));
    } catch (e) {
      setErr(e?.response?.data?.message || "Failed to load products");
    }
  }, []);

  React.useEffect(() => { load(); }, [load]);

  const create = async (e) => {
    e.preventDefault();
    setErr(""); setMsg("");

    try {
      if (!canManage) return setErr("Login as seller/admin");

      await api.post("/products", {
        title: title.trim(),
        category: category.trim(),
        description: description.trim(),
        price: Number(price),
        stock: Number(stock),
        tags: tags.split(",").map(t => t.trim()).filter(Boolean),
      });

      setMsg("Created!");
      setTitle(""); setCategory(""); setDescription("");
      setPrice(""); setStock(""); setTags("");
      await load();
    } catch (e2) {
      setErr(e2?.response?.data?.message || "Create failed");
    }
  };

  return (
    <div className="grid2">
      <div className="card">
        <div className="h1">Manage Products</div>
        {err && <div className="msgErr">{err}</div>}
        {msg && <div style={{ color: "green" }}>{msg}</div>}

        <div style={{ marginTop: 12, display: "grid", gap: 8 }}>
          {items.map(p => (
            <div key={p._id} style={{ border: "1px solid #eee", padding: 10 }}>
              <b>{p.title}</b>
              <div style={{ fontSize: 12, color: "#777" }}>
                {p.category} — ${Number(p.price).toFixed(2)} — stock {p.stock}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="card">
        <div className="h2">Create Product</div>
        {canManage ? (
          <form onSubmit={create} style={{ display: "grid", gap: 10 }}>
            <input className="input" value={title} onChange={e=>setTitle(e.target.value)} placeholder="Title" required />
            <input className="input" value={category} onChange={e=>setCategory(e.target.value)} placeholder="Category" required />
            <textarea className="input" value={description} onChange={e=>setDescription(e.target.value)} placeholder="Description" rows={3} />
            <div className="formRow">
              <input className="input" value={price} onChange={e=>setPrice(e.target.value)} placeholder="Price" required />
              <input className="input" value={stock} onChange={e=>setStock(e.target.value)} placeholder="Stock" required />
            </div>
            <input className="input" value={tags} onChange={e=>setTags(e.target.value)} placeholder="Tags (comma separated)" />
            <button className="btn primary" type="submit">Create</button>
          </form>
        ) : (
          <div className="small">Login as seller/admin to manage products.</div>
        )}
      </div>
    </div>
  );
}
