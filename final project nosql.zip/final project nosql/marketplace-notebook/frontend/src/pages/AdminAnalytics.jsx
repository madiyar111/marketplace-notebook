import React from "react";
import { api } from "../api";
import { getUser } from "../auth";

export default function AdminAnalytics() {
  const user = getUser();

  const [loading, setLoading] = React.useState(false);
  const [msg, setMsg] = React.useState("");

  const [overview, setOverview] = React.useState(null);
  const [rev, setRev] = React.useState(null);
  const [top, setTop] = React.useState([]);
  const [ordersStatus, setOrdersStatus] = React.useState([]);
  const [cats, setCats] = React.useState([]);

  const fmtInt = (n) => Number(n || 0).toLocaleString();
  const fmtMoney = (n) => "₹" + Number(n || 0).toLocaleString();

  const load = async () => {
    setLoading(true);
    setMsg("");

    try {
      const [ovRes, revRes, topRes, stRes, catRes] = await Promise.all([
        api.get("/analytics/overview"),
        api.get("/analytics/revenue"),
        api.get("/analytics/top-products"),
        api.get("/analytics/orders-by-status"),
        api.get("/analytics/products-by-category"),
      ]);

      setOverview(ovRes.data || null);
      setRev(revRes.data || null);
      setTop(Array.isArray(topRes.data) ? topRes.data : []);
      setOrdersStatus(Array.isArray(stRes.data) ? stRes.data : []);
      setCats(Array.isArray(catRes.data) ? catRes.data : []);
    } catch (e) {
      console.error(e);
      setMsg(e?.response?.data?.message || e?.message || "Analytics error");
    } finally {
      setLoading(false);
    }
  };

  const maxCat = Math.max(1, ...cats.map((c) => c.count || 0));
  const maxStatus = Math.max(1, ...ordersStatus.map((x) => x.count || 0));

  return (
    <div style={{ display: "grid", gap: 16 }}>
      <div className="card">
        <div className="h1">Analytics</div>
        <div className="sub">Admin dashboard (orders + products)</div>

        <div className="small" style={{ marginBottom: 10 }}>
          Current user: {user ? `${user.name} (${user.role})` : "not logged in"}
        </div>

        <button className="btn primary" onClick={load} disabled={loading}>
          {loading ? "Loading..." : "Load analytics"}
        </button>

        {msg && <div className="msgErr" style={{ marginTop: 12 }}>{msg}</div>}
      </div>

      {/* KPI cards */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(4, 1fr)",
          gap: 12,
        }}
      >
        <div className="card">
          <div className="small">Users</div>
          <div style={{ fontSize: 26, fontWeight: 900 }}>{fmtInt(overview?.users)}</div>
        </div>
        <div className="card">
          <div className="small">Products</div>
          <div style={{ fontSize: 26, fontWeight: 900 }}>{fmtInt(overview?.products)}</div>
        </div>
        <div className="card">
          <div className="small">Orders</div>
          <div style={{ fontSize: 26, fontWeight: 900 }}>{fmtInt(overview?.orders)}</div>
        </div>
        <div className="card">
          <div className="small">Revenue (paid)</div>
          <div style={{ fontSize: 26, fontWeight: 900 }}>{fmtMoney(rev?.revenue)}</div>
          <div className="small">Paid orders: {fmtInt(rev?.totalOrders)}</div>
        </div>
      </div>

      {/* Orders by status */}
      <div className="card">
        <div style={{ fontWeight: 900, marginBottom: 10 }}>Orders by status</div>

        {ordersStatus.length === 0 ? (
          <div className="small">No orders yet (create orders to see charts).</div>
        ) : (
          <div style={{ display: "grid", gap: 10 }}>
            {ordersStatus.map((x) => (
              <div key={x.status} style={{ display: "grid", gap: 6 }}>
                <div className="small" style={{ display: "flex", justifyContent: "space-between" }}>
                  <span>{x.status}</span>
                  <span>{fmtInt(x.count)}</span>
                </div>
                <div
                  style={{
                    height: 10,
                    borderRadius: 999,
                    background: "rgba(255,255,255,.06)",
                    border: "1px solid rgba(255,255,255,.08)",
                    overflow: "hidden",
                  }}
                >
                  <div
                    style={{
                      height: "100%",
                      width: `${Math.round(((x.count || 0) / maxStatus) * 100)}%`,
                      background: "rgba(255,153,0,.35)",
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Products by category */}
      <div className="card">
        <div style={{ fontWeight: 900, marginBottom: 10 }}>Products by category (Top 15)</div>

        {cats.length === 0 ? (
          <div className="small">No products / categories found.</div>
        ) : (
          <div style={{ display: "grid", gap: 10 }}>
            {cats.map((c) => (
              <div key={c.category} style={{ display: "grid", gap: 6 }}>
                <div className="small" style={{ display: "flex", justifyContent: "space-between" }}>
                  <span>{c.category}</span>
                  <span>{fmtInt(c.count)}</span>
                </div>

                <div
                  style={{
                    height: 10,
                    borderRadius: 999,
                    background: "rgba(255,255,255,.06)",
                    border: "1px solid rgba(255,255,255,.08)",
                    overflow: "hidden",
                  }}
                >
                  <div
                    style={{
                      height: "100%",
                      width: `${Math.round(((c.count || 0) / maxCat) * 100)}%`,
                      background: "rgba(20,110,180,.45)",
                    }}
                  />
                </div>

                <div className="small">
                  avg price: {fmtMoney(c.avgPrice)} • stock avg: {fmtInt(c.avgStock)}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Top products */}
      <div className="card">
        <div style={{ fontWeight: 900, marginBottom: 10 }}>Top products (paid orders)</div>

        {top.length === 0 ? (
          <div className="small">No paid orders yet → top products will appear after checkout/payment.</div>
        ) : (
          <div style={{ display: "grid", gap: 10 }}>
            {top.map((x, idx) => (
              <div
                key={idx}
                style={{
                  border: "1px solid rgba(255,255,255,.08)",
                  borderRadius: 14,
                  padding: 12,
                  background: "rgba(255,255,255,.03)",
                }}
              >
                <div style={{ fontWeight: 900 }}>{x.title}</div>
                <div className="small">category: {x.category || "-"}</div>
                <div className="small">
                  sold: {fmtInt(x.totalSold)} • revenue: {fmtMoney(x.revenue)}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
