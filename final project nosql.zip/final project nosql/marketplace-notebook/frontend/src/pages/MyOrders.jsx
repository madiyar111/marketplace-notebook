// frontend/src/pages/MyOrders.jsx
import React from "react";
import { api } from "../api";

export default function MyOrders() {
  const [orders, setOrders] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const [err, setErr] = React.useState("");
  const [msg, setMsg] = React.useState("");

  const load = React.useCallback(async () => {
    setErr("");
    setMsg("");
    setLoading(true);
    try {
      const res = await api.get("/orders/my"); // GET /orders/my
      setOrders(res.data || []);
    } catch (e) {
      setErr(e?.response?.data?.message || "Failed to load orders (login required)");
      setOrders([]);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    load();
  }, [load]);

  const cancel = async (id) => {
    setErr("");
    setMsg("");
    try {
      await api.patch(`/orders/${id}/cancel`); // PATCH /orders/:id/cancel
      setMsg("Order cancelled ✅ (stock should return)");
      await load();
    } catch (e) {
      setErr(e?.response?.data?.message || "Cancel failed");
    }
  };

  return (
    <div style={{ display: "grid", gap: 14 }}>
      <div className="card" style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
        <h2 style={{ margin: 0 }}>My Orders</h2>
        <button className="btn" onClick={load} disabled={loading}>
          {loading ? "Loading..." : "Refresh"}
        </button>
      </div>

      {err && <div className="card msgErr">{err}</div>}
      {msg && <div className="card" style={{ color: "green" }}>{msg}</div>}

      {loading ? (
        <div className="card">Loading…</div>
      ) : orders.length === 0 ? (
        <div className="card" style={{ color: "#666" }}>No orders yet.</div>
      ) : (
        orders.map((o) => (
          <div key={o._id} className="card" style={{ display: "grid", gap: 10 }}>
            <div style={{ display: "flex", justifyContent: "space-between", gap: 10, flexWrap: "wrap" }}>
              <b>Order: {o._id}</b>
              <span>Status: {o.status}</span>
            </div>

            <div style={{ display: "flex", justifyContent: "space-between", gap: 10, flexWrap: "wrap" }}>
              <div>Total: ${Number(o.totalPrice ?? o.total ?? 0).toFixed(2)}</div>
              <div style={{ fontSize: 12, color: "#777" }}>
                {o.createdAt ? new Date(o.createdAt).toLocaleString() : ""}
              </div>
            </div>

            {Array.isArray(o.items) && o.items.length > 0 && (
              <div style={{ borderTop: "1px solid #eee", paddingTop: 10, display: "grid", gap: 6 }}>
                {o.items.map((it, idx) => (
                  <div key={idx} style={{ fontSize: 14 }}>
                    {it.title ? <b>{it.title}</b> : <>productId: {it.productId}</>}{" "}
                    — qty: {it.quantity} — price: ${Number(it.priceAtPurchase ?? it.price ?? 0).toFixed(2)}
                  </div>
                ))}
              </div>
            )}

            {o.status !== "cancelled" && (
              <button className="btn" onClick={() => cancel(o._id)} style={{ width: "fit-content" }}>
                Cancel order
              </button>
            )}
          </div>
        ))
      )}
    </div>
  );
}
