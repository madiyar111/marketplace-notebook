import React from "react";
import { useParams, Link } from "react-router-dom";
import { api } from "../api";
import { getUser } from "../auth";

export default function ProductDetails() {
  const { id } = useParams();
  const user = getUser();

  const [product, setProduct] = React.useState(null);
  const [reviews, setReviews] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const [err, setErr] = React.useState("");
  const [msg, setMsg] = React.useState("");

  const [rating, setRating] = React.useState(5);
  const [comment, setComment] = React.useState("");

  // Helpers (same idea as Products.jsx)
  const getTitle = (p) => p?.title || p?.name || "Product";
  const getImage = (p) => p?.imageUrl || p?.img_link || "";

  const getPrice = (p) => {
    const raw =
      p?.price ??
      (p?.["price(in Rs"] && p?.["price(in Rs"][")"]) ??
      p?.["price(in Rs)"] ??
      0;

    const num = Number(raw);
    return Number.isFinite(num) ? num : 0;
  };

  const pick = (p, keys) => {
    for (const k of keys) {
      const v = p?.[k];
      if (v !== undefined && v !== null && String(v).trim() !== "") return v;
    }
    return null;
  };

  const formatDisplay = (v) => {
    if (v === null || v === undefined) return null;
    const n = Number(v);
    if (Number.isFinite(n)) return `${n}"`;
    return String(v);
  };

  const load = React.useCallback(async () => {
    setLoading(true);
    setErr("");
    setMsg("");

    try {
      const [pRes, rRes] = await Promise.all([
        api.get(`/products/${id}`),
        api.get(`/reviews/product/${id}`),
      ]);

      setProduct(pRes.data);
      setReviews(Array.isArray(rRes.data) ? rRes.data : []);
    } catch (e) {
      setErr(e?.response?.data?.message || e?.message || "Failed to load product");
    } finally {
      setLoading(false);
    }
  }, [id]);

  React.useEffect(() => {
    load();
  }, [load]);

  const submitReview = async (e) => {
    e.preventDefault();
    setErr("");
    setMsg("");

    try {
      await api.post("/reviews", {
        productId: id,
        rating: Number(rating),
        comment: comment.trim(),
      });

      setComment("");
      setMsg("Review added!");
      await load();
    } catch (e2) {
      setErr(
        e2?.response?.data?.message ||
          e2?.message ||
          "Failed to add review (login required)"
      );
    }
  };

  if (loading) return <div className="card">Loading...</div>;
  if (err) return <div className="card msgErr">{err}</div>;
  if (!product) return <div className="card">Product not found.</div>;

  const titleText = getTitle(product);
  const img = getImage(product);
  const priceNum = getPrice(product);

  // ✅ Specs list (handles many possible dataset key names)
  const specs = [
    { label: "Brand", value: pick(product, ["brand", "Brand", "company", "Company", "manufacturer"]) },
    { label: "Processor", value: pick(product, ["processor", "Processor", "cpu", "CPU", "cpu_type", "Cpu"]) },
    { label: "RAM", value: pick(product, ["ram", "RAM", "memory", "Memory"]) },
    { label: "Storage", value: pick(product, ["storage", "Storage", "ssd", "SSD", "hdd", "HDD"]) },
    { label: "GPU", value: pick(product, ["gpu", "GPU", "graphics", "Graphics"]) },
    { label: "OS", value: pick(product, ["os", "OS", "operating_system", "Operating System"]) },
    { label: "Display", value: formatDisplay(pick(product, ["display(in inch)", "display", "screen", "screen_size", "Screen Size"])) },
    { label: "Rating", value: pick(product, ["rating", "Rating"]) },
    { label: "No. of Ratings", value: pick(product, ["no_of_ratings", "ratings_count", "No. of Ratings"]) },
    { label: "No. of Reviews", value: pick(product, ["no_of_reviews", "reviews_count", "No. of Reviews"]) },
  ].filter((s) => s.value !== null && s.value !== undefined && String(s.value).trim() !== "");

  return (
    <div style={{ display: "grid", gap: 14 }}>
      <div className="card" style={{ display: "grid", gap: 10 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <h2 style={{ margin: 0 }}>{titleText}</h2>
          <Link to="/products" className="btn">Back</Link>
        </div>

        <div style={{ display: "flex", gap: 14, alignItems: "center" }}>
          <div
            style={{
              width: 120,
              height: 120,
              borderRadius: 18,
              overflow: "hidden",
              border: "1px solid rgba(255,255,255,0.08)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontWeight: 800,
            }}
          >
            {img ? (
              <img
                src={img}
                alt={titleText}
                style={{ width: "100%", height: "100%", objectFit: "cover" }}
                onError={(e) => {
                  e.currentTarget.style.display = "none";
                }}
              />
            ) : (
              <span>{(titleText?.slice(0, 1) || "P").toUpperCase()}</span>
            )}
          </div>

          <div style={{ display: "grid", gap: 6, flex: 1 }}>
            <div style={{ color: "#777" }}>Category: {product.category || "—"}</div>
            <div>{product.description || "No description."}</div>

            <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
              <div><b>Price:</b> ₹{priceNum.toLocaleString()}</div>
              <div><b>Stock:</b> {product.stock ?? "-"}</div>
            </div>

            {Array.isArray(product.tags) && product.tags.length > 0 && (
              <div style={{ color: "#777" }}>
                <b>Tags:</b> {product.tags.join(", ")}
              </div>
            )}
          </div>
        </div>

        {/* ✅ Specifications section */}
        {specs.length > 0 && (
          <div style={{ marginTop: 6 }}>
            <div style={{ fontWeight: 800, marginBottom: 8 }}>Specifications</div>
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
                gap: 10,
              }}
            >
              {specs.map((s) => (
                <div
                  key={s.label}
                  style={{
                    border: "1px solid rgba(255,255,255,0.08)",
                    borderRadius: 14,
                    padding: "10px 12px",
                  }}
                >
                  <div style={{ fontSize: 12, color: "#888" }}>{s.label}</div>
                  <div style={{ marginTop: 3 }}>{String(s.value)}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="card" style={{ display: "grid", gap: 10 }}>
        <h3 style={{ margin: 0 }}>Reviews</h3>

        {reviews.length === 0 ? (
          <div style={{ color: "#777" }}>No reviews yet.</div>
        ) : (
          <div style={{ display: "grid", gap: 10 }}>
            {reviews.map((r) => (
              <div key={r._id} style={{ border: "1px solid #eee", padding: 10 }}>
                <div><b>Rating:</b> {r.rating} / 5</div>
                <div style={{ marginTop: 6 }}>{r.comment}</div>
                <div style={{ marginTop: 6, fontSize: 12, color: "#888" }}>
                  {r.createdAt ? new Date(r.createdAt).toLocaleString() : ""}
                </div>
              </div>
            ))}
          </div>
        )}

        <hr />

        <h4 style={{ margin: 0 }}>Add a review</h4>

        {user ? (
          <form onSubmit={submitReview} style={{ display: "grid", gap: 10, maxWidth: 520 }}>
            <label>
              Rating:
              <select
                value={rating}
                onChange={(e) => setRating(e.target.value)}
                style={{ marginLeft: 8 }}
              >
                {[5, 4, 3, 2, 1].map((x) => (
                  <option key={x} value={x}>{x}</option>
                ))}
              </select>
            </label>

            <textarea
              className="input"
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Write your review..."
              rows={3}
              required
            />

            <button className="btn primary" type="submit">Submit</button>
            {msg && <div style={{ color: "green" }}>{msg}</div>}
          </form>
        ) : (
          <div style={{ color: "#777" }}>Login to add a review.</div>
        )}
      </div>
    </div>
  );
}
