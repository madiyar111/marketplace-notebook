import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../api";
import { setAuth } from "../auth";

export default function Register() {
  const nav = useNavigate();
  const [name, setName] = useState("User");
  const [email, setEmail] = useState("user@test.com");
  const [password, setPassword] = useState("123456");
  const [role, setRole] = useState("customer");
  const [msg, setMsg] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    setMsg("");
    try {
      const { data } = await api.post("/auth/register", { name, email, password, role });
      setAuth(data);
      nav("/products");
    } catch (err) {
      setMsg(err?.response?.data?.message || "Register error");
    }
  };

  return (
    <div style={{ maxWidth: 420 }}>
      <h2>Register</h2>
      <form onSubmit={submit} style={{ display: "grid", gap: 10 }}>
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="name" />
        <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="email" />
        <input value={password} onChange={(e) => setPassword(e.target.value)} placeholder="password" type="password" />

        <label>
          Role:
          <select value={role} onChange={(e) => setRole(e.target.value)} style={{ marginLeft: 8 }}>
            <option value="customer">customer</option>
            <option value="seller">seller</option>
            <option value="admin">admin</option>
          </select>
        </label>

        <button type="submit">Create account</button>
        {msg && <div style={{ color: "crimson" }}>{msg}</div>}
        <div style={{ fontSize: 12, color: "#555" }}>
          Подсказка: роль <b>admin</b> даст доступ к Analytics, роль <b>seller</b> — к созданию товаров.
        </div>
      </form>
    </div>
  );
}
