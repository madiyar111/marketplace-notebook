const KEY = "mp_cart_v1";

function safeParse(json, fallback) {
  try {
    return JSON.parse(json);
  } catch {
    return fallback;
  }
}

function notify() {
  // custom event so UI updates immediately
  window.dispatchEvent(new Event("cart:change"));
}

export function getCart() {
  const raw = localStorage.getItem(KEY);
  const cart = safeParse(raw || "null", null);
  return cart && typeof cart === "object" && Array.isArray(cart.items)
    ? cart
    : { items: [] };
}

export function setCart(cart) {
  localStorage.setItem(KEY, JSON.stringify(cart));
  notify();
}

export function clearCart() {
  setCart({ items: [] });
}

export function getCartItems() {
  return getCart().items;
}

export function cartCount() {
  return getCartItems().reduce((sum, it) => sum + Number(it.qty || 0), 0);
}

export function cartSubtotal() {
  return getCartItems().reduce(
    (sum, it) => sum + Number(it.qty || 0) * Number(it.price || 0),
    0
  );
}

// Add product to cart (works with both dataset schema + your schema)
export function addToCart(product, qty = 1) {
  const p = product || {};
  const productId = p._id;
  if (!productId) return;

  const title = p.title || p.name || "Product";
  const imageUrl = p.imageUrl || p.img_link || "";

  // support dataset weird price
  const rawPrice =
    p.price ??
    (p["price(in Rs"] && p["price(in Rs"][")"]) ??
    p["price(in Rs)"] ??
    0;

  const price = Number(rawPrice) || 0;

  const cart = getCart();
  const items = [...cart.items];

  const idx = items.findIndex((x) => x.productId === productId);
  if (idx >= 0) {
    items[idx] = { ...items[idx], qty: items[idx].qty + Number(qty || 1) };
  } else {
    items.push({
      productId,
      title,
      price,
      imageUrl,
      qty: Number(qty || 1),
    });
  }

  setCart({ items });
}

export function removeFromCart(productId) {
  const cart = getCart();
  const items = cart.items.filter((x) => x.productId !== productId);
  setCart({ items });
}

export function setQty(productId, qty) {
  const q = Number(qty);
  if (!Number.isFinite(q)) return;

  if (q <= 0) {
    removeFromCart(productId);
    return;
  }

  const cart = getCart();
  const items = cart.items.map((x) =>
    x.productId === productId ? { ...x, qty: q } : x
  );
  setCart({ items });
}
